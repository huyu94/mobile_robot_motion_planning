1. 运行MinimumSnapCloseForm。
2. 在图上随机选点，然后回车终止。
